# CONTRIBUTING

If you want to contribute to the distribution, fork its [repository on
GitHub](https://github.com/maxmind/GeoIP2-perl). Note that the
`maxmind-db` directory is a git *submodule*. You can obtain it by
adding `--recursive` to the `git clone` command, or by doing a 

    git submodule update --init --recursive

in an already cloned repo.
